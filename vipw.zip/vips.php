<html>
<?php
include_once 'include/header.php';
// Данные базы. Сюда прописывать данные, которые вписаны в databases.cfg
$host = '127.0.0.1'; 	  // Хост БД
$database = 'vip';  // База данных
$user = 'root';		// Пользователь базы
$pass = 'Scpc1990';		   // Пароль пользователя
$server0 = 'SYR|SERVERS';   // Название первого сервера
$server1 = 'SYR|SERVERS';  // Названия второго сервера

$conn = mysqli_connect($host, $user, $pass, $database);
mysqli_query($conn,"set names utf8");
// Запрос
$vips = mysqli_query($conn,"SELECT * 
FROM vip_users, vip_overrides
WHERE id = user_id");
?>
<h3 class="text-info">
				
List of VIP players on the server
			</h3>
			<hr>
<table class="table table-bordered table-hover">
    <tr class="active">
    <th>STEAM_ID</th>
	<th>Name</th>
	<th> Group </th>
    <th>Server</th>
	<th>Expiration Date</th>
    </tr>
<?php
// Вывод
while($vip = mysqli_fetch_array($vips))
{
echo ('<tr class="active">
        <td>'.$vip['auth'].'</td>
        <td>'.$vip['name'].'</td>
		<td>'.$vip['group'].'</td>
   <td>');
   if($vip['server_id'] == 0)
    {
       echo $server0;
    }
    elseif($vip['server_id'] == 1) 
    {
            echo $server1;
    } 
	echo ('</td><td>');
if($vip['expires'] == 0)
    {
            echo "Forever";
    }
    else {
            echo date('d-m-Y H:i', $vip['expires']);
    }
	echo ('</td></tr>');
	}
// Подсчёт випов
	echo('<tr class="active">
        <td colspan="4">Total VIP players:</td>
        <td>');
$result = mysqli_query($conn, "SELECT count(*) FROM vip_users");
$roww = mysqli_fetch_row($result);
$total = $roww[0];
echo $total;
echo ('</td></tr></table>');
mysqli_close($conn);
include_once 'include/footer.php';
?>
</html>