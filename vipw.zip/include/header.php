﻿<head>
<title>VIP players</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
<meta charset="utf-8">
</head>
