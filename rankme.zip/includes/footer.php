<div class="row">
    <div class="footer col-sm-12">
        <div class="row">
            <div class="col-sm-8">
                <h5>Levels Ranks WEB <?=$config['LR_VERS'];?></h5>
                <p>Levels Ranks - это отличный плагин, который имеет в своем арсенале поддержку 2 типов статистики и 2 типов рангов на вкус и цвет каждого админа сервера.</p>
                <p>2017 © <a href="<?php if(isset($config['MAIN_SITE'])){ echo $config['MAIN_SITE'];}else{ echo $config['MAIN_PAGE'];}?>"><?=$config['NAME_PROJ']?></a></p>
            </div>
            <div class="col-sm-4 right">
                <h5 class="white-text">Ссылки</h5>
                    <?php // Сайтам с уделёнными/измененными ссылками на темы и копирайтом в поддержке отказываю ?>
                    <p><a href="http://hlmod.ru/resources/levels-ranks-core.177/">Levels Ranks Plugins</a></p>
                    <p><a href="#">Levels Ranks Web (Fork)</a></p>
                <p>Developed by <a href="https://lordfear.ru/">Lord FEAR</a> && <a href="https://t.me/alexbu444/">Alexmo812</a></p>
            </div>
         </div>
    </div>
</div>