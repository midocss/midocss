<footer class="modal-footer">
			<div class="pull-left">
			<p>Copyright &copy; 2018 All right reserved to <b>
<a href="https://www.facebook.com/midocss1990"><font color="red">Mido CSS</font></a></b> &reg; SYR|SERVERS</font>
</p>
			</div>
		</footer>